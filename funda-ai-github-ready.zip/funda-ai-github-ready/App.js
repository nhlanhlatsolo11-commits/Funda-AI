import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { ProfileProvider } from './src/ProfileContext';
import { LibraryProvider } from './src/LibraryContext';
import AppNavigator from './src/navigation/AppNavigator';
export default function App(){ return <ProfileProvider><LibraryProvider><StatusBar style="dark"/><AppNavigator/></LibraryProvider></ProfileProvider>; }
