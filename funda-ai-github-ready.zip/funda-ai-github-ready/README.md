# Funda AI

**Funda AI** is a Foundation Phase teaching companion for South African educators working with Grades R–3. It provides lesson-plan generation, classroom activity generation, CAPS-aligned lookup and an AI teaching assistant through a secure server-side backend.

## Repository structure

```text
funda-ai/
├── App.js
├── app.json
├── package.json
├── babel.config.js
├── CAPS_SOURCES.md
├── render.yaml
├── README.md
├── .gitignore
├── assets/
├── src/
│   ├── api.js
│   ├── data.js
│   ├── LibraryContext.js
│   ├── ProfileContext.js
│   ├── theme.js
│   ├── components/
│   ├── navigation/
│   └── screens/
└── backend/
    ├── package.json
    ├── .env.example
    ├── README.md
    └── src/
        ├── server.js
        └── caps.js
```

The mobile application never contains the OpenAI API key. The key stays in Render environment variables and the Android app communicates with the backend over HTTPS.

## 1. Prerequisites

Install:

- Git
- Node.js 20 or newer
- npm
- An OpenAI API key
- A GitHub account
- A Render account
- Expo/EAS CLI if you want to build the Android APK/AAB

## 2. Create the GitHub repository

Create an empty GitHub repository, for example:

```text
funda-ai
```

Do not add a README, `.gitignore`, or license through GitHub's creation screen because this project already contains them.

From the project directory:

```bash
git init
git branch -M main
git add .
git commit -m "Initial Funda AI release"
git remote add origin https://github.com/YOUR-GITHUB-USERNAME/funda-ai.git
git push -u origin main
```

Replace `YOUR-GITHUB-USERNAME` with your GitHub username.

## 3. Deploy the backend to Render

The repository is already configured as a Render Blueprint in `render.yaml`.

### Render settings

| Setting | Value |
|---|---|
| Service | `funda-ai-backend` |
| Runtime | Node |
| Region | Frankfurt |
| Plan | Free for initial testing |
| Root Directory | `backend` |
| Build Command | `npm install` |
| Start Command | `npm start` |
| Health Check | `/health` |
| Auto Deploy | Enabled |

Render's root directory means the backend commands run relative to `backend/`, which is appropriate for this repository's monorepo layout.

### Deploy using Render Dashboard

1. Sign in to Render.
2. Choose **New → Blueprint**.
3. Connect GitHub if it is not already connected.
4. Select the `funda-ai` repository.
5. Render will detect `render.yaml`.
6. Confirm the `funda-ai-backend` service.
7. Deploy the Blueprint.
8. Open the service's **Environment** section.
9. Add the required secret values below.
10. Save and redeploy if Render requests it.

### Required environment variables

Set these in Render. Never commit the real OpenAI key to GitHub.

```text
OPENAI_API_KEY=YOUR_REAL_OPENAI_API_KEY
OPENAI_MODEL=gpt-5
ALLOWED_ORIGINS=*
RATE_LIMIT_MAX=60
NODE_ENV=production
```

`OPENAI_API_KEY` and `ALLOWED_ORIGINS` are intentionally marked `sync: false` in the Blueprint so their values are supplied securely through Render rather than committed to source control.

For the first Android test build, `ALLOWED_ORIGINS=*` is acceptable because the mobile client is not a browser origin. If a web client is added later, restrict this value to the trusted origins.

## 4. Verify the backend

After Render finishes deploying, copy the generated HTTPS service URL, for example:

```text
https://funda-ai-backend.onrender.com
```

Open:

```text
https://YOUR-RENDER-URL.onrender.com/health
```

You should receive a response similar to:

```json
{
  "ok": true,
  "service": "funda-ai-backend",
  "version": "1.0.0"
}
```

## 5. Connect the Android app to the backend

Open `app.json` and change:

```json
"apiBaseUrl": "https://YOUR-FUNDA-BACKEND.example.com"
```

to your real Render URL:

```json
"apiBaseUrl": "https://funda-ai-backend.onrender.com"
```

Do not add `/v1/generate` to this value. The application adds its API paths automatically.

Do not put `OPENAI_API_KEY` anywhere in `app.json`.

Commit the change:

```bash
git add app.json
git commit -m "Configure production Funda AI backend"
git push
```

## 6. Install the mobile app dependencies

From the repository root:

```bash
npm install
```

Start the Expo development server:

```bash
npm start
```

For Android development:

```bash
npm run android
```

## 7. Build the Android APK

For a cloud Android build using Expo Application Services:

```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
```

Use the generated EAS build output to download the installable APK.

For a Play Store release, use an Android App Bundle instead of an APK where appropriate:

```bash
eas build --platform android --profile production
```

## 8. Production checklist

Before distributing Funda AI:

- [ ] Backend `/health` responds successfully.
- [ ] `OPENAI_API_KEY` is stored only in Render.
- [ ] `app.json` contains only the public backend URL.
- [ ] AI generation works from the Android app.
- [ ] Lesson plans return CAPS context.
- [ ] Activities return CAPS context.
- [ ] Ask Funda works.
- [ ] Rate limiting is enabled.
- [ ] HTTPS is used for the backend URL.
- [ ] No `.env` file is committed.
- [ ] No API key appears in Git history.

## 9. Local backend development

```bash
cd backend
npm install
cp .env.example .env
npm start
```

Set your local `.env` values before starting the server.

The backend exposes:

```text
GET  /health
GET  /v1/caps?grade=Grade%201&subject=Mathematics&topic=number
POST /v1/generate
```

## CAPS curriculum note

The application contains a concise, paraphrased CAPS-aligned retrieval index for Grades R–3 English and Mathematics. It is designed to give the AI useful curriculum context without reproducing complete copyrighted curriculum documents. The official South African Department of Basic Education CAPS publications remain the authoritative curriculum sources. See `CAPS_SOURCES.md`.

## Security note

The backend validates requests, applies security headers, limits request body size, rate-limits generation requests, returns request IDs for troubleshooting and keeps the OpenAI API key server-side.

Never commit secrets. If an API key is accidentally exposed, revoke it immediately and create a replacement.

## License

This repository is prepared as the Funda AI application project. Add the project's final licensing terms before making the repository public.
