import Constants from 'expo-constants';

const config = Constants.expoConfig?.extra?.fundaAi || {};
const API_BASE_URL = String(config.apiBaseUrl || '').replace(/\/$/, '');

export async function generateWithFunda(payload) {
  if (!API_BASE_URL) throw new Error('Funda AI backend is not configured.');
  const response = await fetch(`${API_BASE_URL}/v1/generate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Funda AI could not complete the request.');
  return data;
}

export async function askFunda(messages, profile) {
  return generateWithFunda({ type: 'chat', messages, profile });
}

export async function generateLessonPlan({ profile, term, topic }) {
  return generateWithFunda({ type: 'lesson_plan', profile, term, topic });
}

export async function generateActivity({ profile, term, topic }) {
  return generateWithFunda({ type: 'activity', profile, term, topic });
}
