import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography } from '../theme';

export default function SubHeader({ title, onBack }) {
  return (
    <View style={styles.row}>
      <Pressable style={styles.backBtn} onPress={onBack}>
        <Ionicons name="chevron-back" size={18} color={colors.ink} />
      </Pressable>
      <Text style={typography.h2}>{title}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', paddingTop: 16, paddingBottom: 8 },
  backBtn: {
    width: 34,
    height: 34,
    borderRadius: 10,
    backgroundColor: colors.cardWhite,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
});
