import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { colors, radius, spacing } from '../theme';

// sections: [{ heading, body }]
// onSave: optional — pass to show a "Save to library" action
export default function ResultCard({ tag, title, sections, onEdit, onSave }) {
  return (
    <View style={styles.card}>
      <View style={styles.tagWrap}>
        <Text style={styles.tagText}>{tag}</Text>
      </View>
      <Text style={styles.title}>{title}</Text>

      {sections.map((s) => (
        <View key={s.heading} style={styles.section}>
          <Text style={styles.sectionHeading}>{s.heading}</Text>
          <Text style={styles.sectionBody}>{s.body}</Text>
        </View>
      ))}

      <View style={styles.actions}>
        {onEdit && (
          <Pressable style={styles.secondaryBtn} onPress={onEdit}>
            <Text style={styles.secondaryLabel}>Edit</Text>
          </Pressable>
        )}
        {onSave && (
          <Pressable style={styles.saveBtn} onPress={onSave}>
            <Text style={styles.saveLabel}>Save to library</Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.cardWhite,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: spacing.md,
    marginTop: spacing.lg,
  },
  tagWrap: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(201,154,62,0.15)',
    paddingVertical: 3,
    paddingHorizontal: 8,
    borderRadius: 6,
    marginBottom: spacing.sm,
  },
  tagText: {
    fontSize: 10.5,
    fontWeight: '700',
    color: colors.gold,
  },
  title: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.chalkGreen,
  },
  section: {
    marginTop: spacing.sm + 4,
  },
  sectionHeading: {
    fontSize: 12.5,
    fontWeight: '700',
    color: colors.inkSoft,
  },
  sectionBody: {
    fontSize: 13.5,
    color: colors.ink,
    marginTop: 4,
    lineHeight: 19,
  },
  actions: {
    flexDirection: 'row',
    marginTop: spacing.lg,
  },
  secondaryBtn: {
    flex: 1,
    padding: 12,
    borderRadius: radius.sm,
    borderWidth: 1.5,
    borderColor: colors.border,
    backgroundColor: colors.cardWhite,
    marginRight: spacing.sm,
    alignItems: 'center',
  },
  secondaryLabel: {
    fontSize: 13.5,
    fontWeight: '700',
    color: colors.ink,
  },
  saveBtn: {
    flex: 1,
    padding: 12,
    borderRadius: radius.sm,
    backgroundColor: colors.chalkGreen,
    alignItems: 'center',
  },
  saveLabel: {
    fontSize: 13.5,
    fontWeight: '700',
    color: colors.bgPaper,
  },
});
