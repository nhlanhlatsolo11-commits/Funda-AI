import React, { createContext, useContext, useState } from 'react';

const LibraryContext = createContext(null);
export function LibraryProvider({ children }) {
  const [items, setItems] = useState([]);
  const saveItem = item => setItems(prev => [{...item, id: String(Date.now())}, ...prev.filter(x => x.title !== item.title)]);
  const removeItem = id => setItems(prev => prev.filter(x => x.id !== id));
  return <LibraryContext.Provider value={{items, saveItem, removeItem}}>{children}</LibraryContext.Provider>;
}
export function useLibrary(){ const ctx=useContext(LibraryContext); if(!ctx) throw new Error('useLibrary must be used within LibraryProvider'); return ctx; }
