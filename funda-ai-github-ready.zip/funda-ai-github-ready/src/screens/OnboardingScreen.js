import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet } from 'react-native';
import Chip from '../components/Chip';
import { useProfile } from '../ProfileContext';
import { colors, spacing, typography } from '../theme';

const GRADES = ['Grade R', 'Grade 1', 'Grade 2', 'Grade 3'];
const SUBJECTS = ['English', 'Mathematics'];
const LANGUAGES = ['English', 'Sesotho'];

export default function OnboardingScreen({ navigation }) {
  const { profile, setProfile } = useProfile();
  const [grade, setGrade] = useState(profile.grade);
  const [subject, setSubject] = useState(profile.subject);
  const [language, setLanguage] = useState(profile.language);

  function handleContinue() {
    setProfile({ grade, subject, language });
    navigation.replace('Home');
  }

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <Text style={typography.h1}>Dumela! Let's set up{'\n'}your classroom</Text>
      <Text style={[typography.body, { color: colors.inkSoft, marginTop: 8 }]}>
        This takes less than a minute — you can change it anytime.
      </Text>

      <Text style={[typography.label, styles.fieldLabel]}>Grade</Text>
      <View style={styles.chipRow}>
        {GRADES.map((g) => (
          <Chip key={g} label={g} selected={grade === g} onPress={() => setGrade(g)} />
        ))}
      </View>

      <Text style={[typography.label, styles.fieldLabel]}>Subject</Text>
      <View style={styles.chipRow}>
        {SUBJECTS.map((s) => (
          <Chip key={s} label={s} selected={subject === s} onPress={() => setSubject(s)} />
        ))}
      </View>

      <Text style={[typography.label, styles.fieldLabel]}>Language</Text>
      <View style={styles.chipRow}>
        {LANGUAGES.map((l) => (
          <Chip key={l} label={l} selected={language === l} onPress={() => setLanguage(l)} />
        ))}
      </View>

      <Pressable style={styles.primaryBtn} onPress={handleContinue}>
        <Text style={styles.primaryLabel}>Get started</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bgPaper },
  content: { padding: spacing.lg, paddingTop: 40, paddingBottom: 60 },
  fieldLabel: { marginTop: 24, marginBottom: 10 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap' },
  primaryBtn: {
    marginTop: 32,
    backgroundColor: colors.chalkGreen,
    borderRadius: 14,
    padding: 16,
    alignItems: 'center',
  },
  primaryLabel: {
    color: colors.bgPaper,
    fontSize: 16,
    fontWeight: '700',
  },
});
