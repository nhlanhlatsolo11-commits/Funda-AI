import React from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import FeatureCard from '../components/FeatureCard';
import { useProfile } from '../ProfileContext';
import { colors, spacing, typography, radius } from '../theme';

export default function HomeScreen({ navigation }) {
  const { profile } = useProfile();

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <View>
            <Text style={typography.h2}>Dumela, Teacher</Text>
            <Text style={[typography.caption, { marginTop: 4 }]}>Ready for today's lessons?</Text>
          </View>
          <View style={styles.profileChip}>
            <Text style={styles.profileChipText}>
              {profile.grade} · {profile.subject}
            </Text>
          </View>
        </View>

        <Text style={[typography.label, styles.sectionLabel]}>Continue where you left off</Text>
        <Pressable
          style={styles.continueCard}
          onPress={() => navigation.navigate('LessonPlans')}
        >
          <View style={styles.continueIcon}>
            <Ionicons name="book-outline" size={18} color={colors.ink} />
          </View>
          <View>
            <Text style={typography.h3}>Phonics: short vowel sounds</Text>
            <Text style={[typography.caption, { marginTop: 2 }]}>Term 1 · Week 4 · Draft saved</Text>
          </View>
        </Pressable>

        <Text style={[typography.label, styles.sectionLabel]}>What do you need today?</Text>
        <View style={styles.grid}>
          <FeatureCard
            icon="book-outline"
            iconBg="rgba(31,68,54,0.1)"
            iconColor={colors.chalkGreen}
            title="Lesson plans"
            subtitle="CAPS-aligned, ready to teach"
            onPress={() => navigation.navigate('LessonPlans')}
          />
          <FeatureCard
            icon="sparkles-outline"
            iconBg="rgba(201,154,62,0.15)"
            iconColor={colors.gold}
            title="Activities"
            subtitle="Worksheets & classroom tasks"
            onPress={() => navigation.navigate('Activities')}
          />
          <FeatureCard
            icon="search-outline"
            iconBg="rgba(166,58,46,0.1)"
            iconColor={colors.penRed}
            title="CAPS lookup"
            subtitle="Ask a curriculum question"
            onPress={() => navigation.navigate('CapsLookup')}
          />
          <FeatureCard
            icon="bookmark-outline"
            iconBg="rgba(43,37,32,0.08)"
            iconColor={colors.ink}
            title="My library"
            subtitle="Saved plans, offline ready"
            onPress={() => navigation.navigate('Library')}
          />
        </View>
      </ScrollView>

      <Pressable style={styles.fab} onPress={() => navigation.navigate('AskFunda')}>
        <Ionicons name="chatbubble-ellipses-outline" size={22} color={colors.bgPaper} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bgPaper },
  content: { padding: spacing.lg, paddingBottom: 100 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  profileChip: {
    backgroundColor: colors.cardWhite,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.pill,
    paddingVertical: 6,
    paddingHorizontal: 10,
  },
  profileChipText: { fontSize: 11, fontWeight: '700', color: colors.chalkGreen },
  sectionLabel: { marginTop: 20, marginBottom: 10 },
  continueCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.cardWhite,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: 14,
  },
  continueIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: colors.gold,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 24,
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: colors.penRed,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.penRed,
    shadowOpacity: 0.4,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 6,
  },
});
