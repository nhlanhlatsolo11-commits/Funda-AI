// Design tokens — "exercise book and chalkboard" visual identity,
// carried over directly from the HTML prototype.
export const colors = {
  bgPaper: '#F3ECDA',
  ink: '#2B2520',
  inkSoft: '#5B5346',
  chalkGreen: '#1F4436',
  chalkGreenLight: '#2C5C4A',
  penRed: '#A63A2E',
  gold: '#C99A3E',
  cardWhite: '#FFFFFF',
  border: '#DDD3B8',
};

export const radius = {
  md: 14,
  sm: 10,
  pill: 999,
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 20,
  xl: 24,
};

export const typography = {
  h1: { fontSize: 26, fontWeight: '700', color: colors.chalkGreen },
  h2: { fontSize: 20, fontWeight: '700', color: colors.chalkGreen },
  h3: { fontSize: 15, fontWeight: '700', color: colors.ink },
  body: { fontSize: 14, color: colors.ink },
  caption: { fontSize: 12, color: colors.inkSoft },
  label: { fontSize: 12, fontWeight: '700', color: colors.inkSoft },
};
