import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import OnboardingScreen from '../screens/OnboardingScreen';
import HomeScreen from '../screens/HomeScreen';
import LessonPlansScreen from '../screens/LessonPlansScreen';
import ActivitiesScreen from '../screens/ActivitiesScreen';
import CapsLookupScreen from '../screens/CapsLookupScreen';
import LibraryScreen from '../screens/LibraryScreen';
import AskFundaScreen from '../screens/AskFundaScreen';

const Stack = createNativeStackNavigator();

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Onboarding"
        screenOptions={{ headerShown: false }}
      >
        <Stack.Screen name="Onboarding" component={OnboardingScreen} />
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="LessonPlans" component={LessonPlansScreen} />
        <Stack.Screen name="Activities" component={ActivitiesScreen} />
        <Stack.Screen name="CapsLookup" component={CapsLookupScreen} />
        <Stack.Screen name="Library" component={LibraryScreen} />
        <Stack.Screen name="AskFunda" component={AskFundaScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
