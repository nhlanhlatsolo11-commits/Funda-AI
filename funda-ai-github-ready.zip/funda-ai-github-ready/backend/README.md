# Funda AI Backend

Secure Node/Express backend for Funda AI. It keeps the OpenAI API key on the server and exposes curriculum lookup and AI generation endpoints to the mobile application.

## Endpoints

- `GET /health`
- `GET /v1/caps?grade=Grade%201&subject=Mathematics&topic=number`
- `POST /v1/generate`

## Local setup

```bash
npm install
cp .env.example .env
npm start
```

Never commit `.env`.

## Render

The repository root contains `render.yaml`. Render should use:

- Root Directory: `backend`
- Build: `npm install`
- Start: `npm start`
- Health check: `/health`
