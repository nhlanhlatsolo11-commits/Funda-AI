// Structured, paraphrased CAPS-aligned index for retrieval. The full policy documents remain the authoritative source.
// Source: South African Department of Basic Education Foundation Phase CAPS portal and Grade R / Grades 1-3 CAPS documents.
const CAPS = [
['Grade R','English','Term 1','Listening & speaking','Oral language, listening, speaking, vocabulary, rhymes, songs and sound awareness.'],
['Grade R','English','Term 1','Phonological awareness','Rhyming, syllables, initial sounds, auditory discrimination and playful sound activities.'],
['Grade R','English','Term 2','Emergent reading','Picture reading, book handling, prediction, sequencing and shared story experiences.'],
['Grade R','English','Term 3','Emergent writing','Drawing, patterning, name writing, mark-making and representing meaning through print.'],
['Grade R','English','Term 4','Oral vocabulary','Retelling, describing, questioning and expanding vocabulary through stories and conversation.'],
['Grade 1','English','Term 1','Phonics & word recognition','Early phonics, sound-symbol relationships, blending, segmenting and high-frequency word development.'],
['Grade 1','English','Term 2','Reading comprehension','Shared and guided reading, prediction, sequencing, vocabulary and literal comprehension.'],
['Grade 1','English','Term 3','Writing','Sentence construction, personal writing, captions, vocabulary and editing with teacher support.'],
['Grade 1','English','Term 4','Oral language','Listening, speaking, retelling, describing and participating in structured conversations.'],
['Grade 2','English','Term 1','Reading fluency','Decoding, accuracy, phrasing, vocabulary and comprehension during guided and independent reading.'],
['Grade 2','English','Term 2','Writing paragraphs','Planning, drafting, sequencing ideas and producing short connected texts.'],
['Grade 2','English','Term 3','Comprehension','Literal and inferential questions, main ideas, vocabulary and response to different texts.'],
['Grade 2','English','Term 4','Language structures','Grammar and punctuation integrated into reading, speaking and writing tasks.'],
['Grade 3','English','Term 1','Reading & comprehension','Fluency, vocabulary, comprehension strategies and response to fiction and informational texts.'],
['Grade 3','English','Term 2','Writing','Planning and writing coherent paragraphs and short texts for different purposes.'],
['Grade 3','English','Term 3','Language use','Grammar, spelling, punctuation and vocabulary applied in meaningful communication.'],
['Grade 3','English','Term 4','Integrated language','Listening, speaking, reading and writing integrated around texts and themes.'],
['Grade R','Mathematics','Term 1','Number & counting','Counting concrete objects, number concepts, comparing collections and recognising numerals in meaningful contexts.'],
['Grade R','Mathematics','Term 1','Patterns','Copying, extending and creating simple patterns using objects, colours, shapes and movement.'],
['Grade R','Mathematics','Term 2','Space & shape','Position, direction, shape recognition, sorting and describing objects using everyday language.'],
['Grade R','Mathematics','Term 3','Measurement','Comparing length, capacity, mass and time through practical activities and informal units.'],
['Grade R','Mathematics','Term 4','Data handling','Collecting, sorting, representing and discussing simple information using concrete objects and pictures.'],
['Grade 1','Mathematics','Term 1','Numbers, operations & relationships','Counting, ordering, comparing, representing numbers and solving simple addition/subtraction problems.'],
['Grade 1','Mathematics','Term 2','Patterns','Copying, extending and creating number, geometric and object patterns.'],
['Grade 1','Mathematics','Term 3','Space & shape','Recognising, describing, sorting and comparing 2-D and 3-D objects and position.'],
['Grade 1','Mathematics','Term 4','Measurement & data','Practical measurement, time, money and simple data collection and representation.'],
['Grade 2','Mathematics','Term 1','Number & operations','Number sense, place value, mental strategies and addition/subtraction with increasingly efficient methods.'],
['Grade 2','Mathematics','Term 2','Patterns & algebra','Number and geometric patterns, describing rules and investigating relationships.'],
['Grade 2','Mathematics','Term 3','Addition & subtraction','Solving contextual problems using concrete apparatus, drawings, number lines and mental strategies.'],
['Grade 2','Mathematics','Term 4','Multiplication & division','Early multiplicative thinking through grouping, sharing, repeated addition and equal groups.'],
['Grade 3','Mathematics','Term 1','Numbers & place value','Reading, writing, ordering and representing numbers, place value and flexible number strategies.'],
['Grade 3','Mathematics','Term 2','Operations','Addition, subtraction, multiplication and division strategies applied to routine and problem-solving contexts.'],
['Grade 3','Mathematics','Term 3','Fractions & measurement','Fractions in practical contexts, measurement, time, length, mass, capacity and problem solving.'],
['Grade 3','Mathematics','Term 4','Geometry & data','Properties of shapes, position, symmetry, data collection, representation and interpretation.'],
];
const items = CAPS.map(([grade,subject,term,topic,content])=>({grade,subject,term,topic,content,source:'DBE CAPS Foundation Phase'}));
export function findCaps(profile, term, topic='') {
  const q=String(topic).toLowerCase().split(/\W+/).filter(Boolean);
  const pool=items.filter(x=>x.grade===profile.grade && x.subject===profile.subject && (!term || x.term===term));
  const fallback=items.filter(x=>x.grade===profile.grade && x.subject===profile.subject);
  const scored=(pool.length?pool:fallback).map(x=>({...x,score:q.reduce((n,w)=>n+(x.topic+' '+x.content).toLowerCase().includes(w)?1:0,0)})).sort((a,b)=>b.score-a.score);
  return scored.slice(0,5);
}
export {items};
