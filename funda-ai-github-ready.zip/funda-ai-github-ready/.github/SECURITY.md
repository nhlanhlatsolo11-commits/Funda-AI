# Security

Do not report or commit API keys, passwords, access tokens, or other credentials in GitHub issues or pull requests.

If an OpenAI API key is exposed, revoke it immediately and create a replacement. Production secrets belong in Render environment variables, not in the mobile application or repository.
