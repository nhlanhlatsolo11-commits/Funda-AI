# Funda AI CAPS curriculum index

Funda AI uses a **structured, paraphrased retrieval index** rather than copying entire CAPS policy documents into the application. The index is designed to help the AI select an appropriate Foundation Phase content area; the official DBE documents remain the authority.

Primary source: South African Department of Basic Education, CAPS for Foundation Phase (Grade R-3):
https://www.education.gov.za/Curriculum/CurriculumAssessmentPolicyStatements%28CAPS%29/CAPSFoundation/tabid/571/Default.aspx

The DBE Foundation Phase portal lists CAPS materials for English, Home Languages, First Additional Languages, Mathematics, Grade R Mathematics and Life Skills.

The initial Funda index focuses on English and Mathematics for Grades R-3 because these are the subjects currently exposed in the app profile. It includes term-level retrieval topics for listening/speaking, phonological awareness, emergent literacy, reading, writing, language structures, number, operations, patterns, space/shape, measurement and data.

The Grade R and Grades 1-3 Mathematics/English source documents used to structure the index are published by DBE, including the Grade R CAPS document and the Foundation Phase Grades 1-3 Mathematics/English document.
